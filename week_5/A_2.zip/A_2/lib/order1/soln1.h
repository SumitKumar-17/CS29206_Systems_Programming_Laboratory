#ifndef SOLN1_H
#define SOLN1_H

typedef struct
{
    int d, c1, a0, a1;
} recrel1;

int findterm1(recrel1 *r, int n);

#endif
